import reactDOM from "react-dom";
import App from "./App";
import user from "./User";
import 'bootstrap/dist/css/bootstrap.css'
import "./index.css";
reactDOM.render(<App/>,document.getElementById("root"));
